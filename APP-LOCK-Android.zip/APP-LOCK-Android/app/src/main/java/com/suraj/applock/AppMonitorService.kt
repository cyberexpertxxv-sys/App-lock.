package com.suraj.applock

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class AppMonitorService : AccessibilityService() {
    private var lastPackage = ""
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == lastPackage) return
        val prefs = getSharedPreferences("lockprefs", MODE_PRIVATE)
        if (!prefs.getBoolean("master", true) || !prefs.getBoolean("locked_$pkg", false)) {
            lastPackage = pkg
            return
        }
        // Avoid repeatedly launching the lock screen while it is already in front.
        lastPackage = pkg
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("show_lock", true)
            putExtra("locked_package", pkg)
        }
        startActivity(intent)
    }
    override fun onInterrupt() {}
}

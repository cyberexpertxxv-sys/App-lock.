package com.suraj.applock

import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("lockprefs", Context.MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private var master = true
    private val purple = Color.rgb(124, 92, 255)
    private val apps = mutableListOf<Pair<String, String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9, 14, 29)
        window.navigationBarColor = Color.rgb(9, 14, 29)
        master = prefs.getBoolean("master", true)
        buildAppList()
        if (intent.getBooleanExtra("show_lock", false)) {
            showPinScreen(intent.getStringExtra("locked_package") ?: "")
        } else renderHome()
    }

    private fun buildAppList() {
        apps.clear()
        val pm = packageManager
        val installed = pm.getInstalledApplications(0)
        for (info in installed) {
            if (info.packageName == packageName) continue
            val label = pm.getApplicationLabel(info).toString()
            if (label.isNotBlank()) apps.add(label to info.packageName)
        }
        apps.sortBy { it.first.lowercase() }
    }

    private fun bg(radius: Float = 24f, color: Int = Color.rgb(18, 26, 45)): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun text(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply { text = value; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }

    private fun renderHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(22, 26, 22, 24); setBackgroundColor(Color.rgb(9, 14, 29))
        }
        val title = text("🔒  APP LOCK", 25f, Color.WHITE, true)
        root.addView(title)
        root.addView(text("Privacy, in your control", 13f, Color.LTGRAY))
        val masterRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = bg(24f, Color.rgb(24, 34, 59)); setPadding(16, 15, 12, 15)
        }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(text("Master protection", 17f, Color.WHITE, true))
        info.addView(text("Turn all selected app locks on/off", 12f, Color.LTGRAY))
        masterRow.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        val masterSwitch = Switch(this).apply { isChecked = master }
        masterSwitch.setOnCheckedChangeListener { _, checked -> master = checked; prefs.edit().putBoolean("master", checked).apply() }
        masterRow.addView(masterSwitch)
        val p = LinearLayout.LayoutParams(-1, -2); p.topMargin = 22
        root.addView(masterRow, p)
        root.addView(text("INSTALLED APPS  •  ${apps.size}", 13f, Color.rgb(160, 174, 210), true).apply { setPadding(2, 22, 0, 10) })
        val search = EditText(this).apply {
            hint = "Search apps"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            background = bg(15f, Color.rgb(20, 29, 49)); setPadding(14, 10, 14, 10)
        }
        root.addView(search)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 12 })
        fun populate(filter: String) {
            list.removeAllViews()
            apps.filter { it.first.contains(filter, true) }.forEach { (label, pkg) ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    background = bg(17f, Color.rgb(18, 26, 45)); setPadding(13, 10, 12, 10)
                }
                val icon = try { packageManager.getApplicationIcon(pkg) } catch (_: Exception) { null }
                val iconView = ImageView(this).apply { if (icon != null) setImageDrawable(icon) }
                row.addView(iconView, LinearLayout.LayoutParams(42, 42))
                val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 0, 0, 0) }
                labels.addView(text(label, 14f, Color.WHITE, true))
                labels.addView(text(pkg, 9f, Color.LTGRAY))
                row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
                val sw = Switch(this).apply { isChecked = prefs.getBoolean("locked_$pkg", false) }
                sw.setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("locked_$pkg", checked).apply() }
                row.addView(sw)
                val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 8
                list.addView(row, lp)
            }
        }
        populate("")
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { populate(s?.toString() ?: "") }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        val access = Button(this).apply { text = "Set up permissions"; setOnClickListener { showPermissionHelp() } }
        root.addView(access, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })
        setContentView(root)
    }

    private fun showPermissionHelp() {
        val options = arrayOf("Usage Access", "Display over other apps", "Accessibility settings")
        AlertDialogBuilderCompat.show(this, "Allow permissions", "Enable the permissions below in Android Settings. Accessibility should only be enabled if you understand and want this monitoring.", options) { which ->
            when (which) {
                0 -> startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                1 -> startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                2 -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
    }

    private fun showPinScreen(lockedPackage: String) {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(9, 14, 29))
        }
        val appLabel = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(lockedPackage, 0)).toString() } catch (_: Exception) { "Protected app" }
        layout.addView(text("🔐", 44f).apply { gravity = Gravity.CENTER })
        layout.addView(text("APP LOCK", 25f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(0, 12, 0, 6) })
        layout.addView(text("$appLabel is locked", 15f, Color.LTGRAY).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, 20) })
        val pin = EditText(this).apply {
            hint = "Enter PIN"; inputType = 129; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            gravity = Gravity.CENTER; textSize = 22f; setPadding(16, 12, 16, 12); background = bg(15f, Color.rgb(20, 29, 49))
        }
        layout.addView(pin, LinearLayout.LayoutParams(-1, -2))
        val error = text("", 13f, Color.rgb(255, 100, 124)).apply { gravity = Gravity.CENTER; setPadding(0, 12, 0, 12) }
        layout.addView(error)
        var wrong = 0
        val unlock = Button(this).apply { text = "Unlock" }
        layout.addView(unlock, LinearLayout.LayoutParams(-1, -2))
        unlock.setOnClickListener {
            if (pin.text.toString() == prefs.getString("pin", "0007")) {
                prefs.edit().putString("last_unlocked", lockedPackage).apply()
                finish()
            } else {
                wrong++
                error.text = when (wrong) {
                    1 -> "Wrong password"
                    2 -> "Nikal Yaha se"
                    else -> { wrong = 0; "Your Password is \"0007\"" }
                }
            }
        }
        setContentView(layout)
        window.setFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED, WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
    }
}

private object AlertDialogBuilderCompat {
    fun show(activity: Activity, title: String, message: String, items: Array<String>, callback: (Int) -> Unit) {
        android.app.AlertDialog.Builder(activity).setTitle(title).setMessage(message)
            .setItems(items) { _, which -> callback(which) }.setNegativeButton("Close", null).show()
    }
}

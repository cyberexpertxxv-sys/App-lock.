# APP LOCK Android project

This is a starter Android Studio project for a personal app-lock prototype.

## Build
Open this folder in Android Studio and build the debug APK, or use the GitHub Actions workflow supplied separately.

## Important limitations and security
- Android OS versions and manufacturers may limit app monitoring, background launches, package visibility, or overlay behavior. Test on your own device.
- User must manually grant Usage Access / overlay permission and explicitly enable the Accessibility service in Settings.
- The requested third-failure PIN reveal (`0007`) makes the lock insecure. This behavior is included only because it was requested; remove it before using this to protect sensitive apps.
- A prototype is not a substitute for Android's secure lock screen. Never collect or transmit app content.
